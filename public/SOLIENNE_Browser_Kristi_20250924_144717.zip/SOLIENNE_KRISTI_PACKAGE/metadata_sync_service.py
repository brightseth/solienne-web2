#!/usr/bin/env python3
"""
SOLIENNE Metadata Sync Service
Shared tagging system between Seth and Kristi
"""

import json
import os
from datetime import datetime
from pathlib import Path
import hashlib

class MetadataSync:
    def __init__(self, user_id="seth"):
        self.user_id = user_id
        self.base_dir = Path(__file__).parent
        self.shared_metadata_file = self.base_dir / "shared_metadata.json"
        self.local_tags_file = self.base_dir / "metadata" / "local_tags.json"
        self.sync_log_file = self.base_dir / "metadata" / "sync_log.json"
        
        # Initialize files if they don't exist
        self.shared_metadata_file.parent.mkdir(exist_ok=True)
        self.local_tags_file.parent.mkdir(exist_ok=True)
        
        self.shared_metadata = self.load_shared_metadata()
        self.local_tags = self.load_local_tags()
        
    def load_shared_metadata(self):
        """Load shared metadata file"""
        if self.shared_metadata_file.exists():
            with open(self.shared_metadata_file) as f:
                return json.load(f)
        return {
            "version": "1.0",
            "last_sync": None,
            "tags": {},
            "manifesto_whitelist": [],
            "portrait_blacklist": [],
            "contributors": {}
        }
        
    def load_local_tags(self):
        """Load local tags from browser localStorage export"""
        if self.local_tags_file.exists():
            with open(self.local_tags_file) as f:
                return json.load(f)
        return {}
        
    def save_shared_metadata(self):
        """Save shared metadata"""
        self.shared_metadata["last_sync"] = datetime.now().isoformat()
        with open(self.shared_metadata_file, 'w') as f:
            json.dump(self.shared_metadata, f, indent=2, sort_keys=True)
            
    def merge_tags(self, local_tags, remote_tags):
        """
        Merge local and remote tags intelligently
        Priority: Manual corrections > Recent updates > Existing tags
        """
        merged = {}
        
        for work_id in set(list(local_tags.keys()) + list(remote_tags.keys())):
            local = local_tags.get(work_id, {})
            remote = remote_tags.get(work_id, {})
            
            # Start with remote as base
            merged[work_id] = remote.copy()
            
            # Override with local manual corrections
            if local.get('is_manifesto') is not None:
                merged[work_id]['is_manifesto'] = local['is_manifesto']
                merged[work_id]['manifesto_tagged_by'] = self.user_id
                merged[work_id]['manifesto_tagged_at'] = datetime.now().isoformat()
                
            if local.get('is_portrait') is not None:
                merged[work_id]['is_portrait'] = local['is_portrait']
                merged[work_id]['portrait_tagged_by'] = self.user_id
                merged[work_id]['portrait_tagged_at'] = datetime.now().isoformat()
                
            # Preserve other local tags
            for key, value in local.items():
                if key not in ['is_manifesto', 'is_portrait'] and value is not None:
                    merged[work_id][key] = value
                    
        return merged
        
    def sync_with_cloud(self, cloud_metadata=None):
        """
        Sync local tags with cloud/shared metadata
        """
        if cloud_metadata:
            # Incoming sync from cloud
            self.shared_metadata = cloud_metadata
            
        # Merge tags
        merged_tags = self.merge_tags(self.local_tags, self.shared_metadata.get('tags', {}))
        
        # Update shared metadata
        self.shared_metadata['tags'] = merged_tags
        
        # Track contributor
        if self.user_id not in self.shared_metadata['contributors']:
            self.shared_metadata['contributors'][self.user_id] = {
                'first_sync': datetime.now().isoformat(),
                'tag_count': 0
            }
        
        # Count tags by this user
        tag_count = sum(
            1 for work in merged_tags.values()
            if work.get('manifesto_tagged_by') == self.user_id or 
               work.get('portrait_tagged_by') == self.user_id
        )
        self.shared_metadata['contributors'][self.user_id]['tag_count'] = tag_count
        self.shared_metadata['contributors'][self.user_id]['last_sync'] = datetime.now().isoformat()
        
        # Save
        self.save_shared_metadata()
        
        # Log sync
        self.log_sync(len(merged_tags))
        
        return merged_tags
        
    def export_for_browser(self):
        """
        Export tags in format ready for browser localStorage import
        """
        browser_tags = {}
        
        for work_id, tags in self.shared_metadata.get('tags', {}).items():
            browser_tags[work_id] = {
                'id': work_id,
                'is_manifesto': tags.get('is_manifesto', False),
                'is_portrait': tags.get('is_portrait', False),
                'is_bw': tags.get('is_bw'),
                'is_color': tags.get('is_color'),
                'has_text': tags.get('has_text'),
                'tagged_by': tags.get('manifesto_tagged_by') or tags.get('portrait_tagged_by'),
                'tagged_at': tags.get('manifesto_tagged_at') or tags.get('portrait_tagged_at')
            }
            
        return browser_tags
        
    def import_from_browser(self, browser_export):
        """
        Import tags from browser localStorage export
        """
        if isinstance(browser_export, str):
            # If it's a JSON string from localStorage
            browser_tags = json.loads(browser_export)
        else:
            browser_tags = browser_export
            
        self.local_tags = browser_tags
        with open(self.local_tags_file, 'w') as f:
            json.dump(browser_tags, f, indent=2)
            
        # Sync with shared metadata
        return self.sync_with_cloud()
        
    def get_manifesto_whitelist(self):
        """Get confirmed manifesto IDs"""
        whitelist = set(self.shared_metadata.get('manifesto_whitelist', []))
        
        # Add any works explicitly tagged as manifestos
        for work_id, tags in self.shared_metadata.get('tags', {}).items():
            if tags.get('is_manifesto') == True:
                # Clean the ID (remove file extension)
                clean_id = work_id.replace('.jpg', '').replace('.jpeg', '').replace('.png', '').replace('.webp', '')
                whitelist.add(clean_id)
                
        return list(whitelist)
        
    def get_portrait_blacklist(self):
        """Get confirmed non-portrait IDs"""
        blacklist = set(self.shared_metadata.get('portrait_blacklist', []))
        
        # Add any works explicitly tagged as NOT portraits
        for work_id, tags in self.shared_metadata.get('tags', {}).items():
            if tags.get('is_portrait') == False and tags.get('is_manifesto') == True:
                clean_id = work_id.replace('.jpg', '').replace('.jpeg', '').replace('.png', '').replace('.webp', '')
                blacklist.add(clean_id)
                
        return list(blacklist)
        
    def log_sync(self, tag_count):
        """Log sync activity"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'user': self.user_id,
            'tags_synced': tag_count,
            'action': 'sync'
        }
        
        # Load existing log
        if self.sync_log_file.exists():
            with open(self.sync_log_file) as f:
                log = json.load(f)
        else:
            log = {'entries': []}
            
        log['entries'].append(log_entry)
        
        # Keep only last 100 entries
        log['entries'] = log['entries'][-100:]
        
        with open(self.sync_log_file, 'w') as f:
            json.dump(log, f, indent=2)
            
    def get_sync_stats(self):
        """Get sync statistics"""
        stats = {
            'total_tags': len(self.shared_metadata.get('tags', {})),
            'manifesto_count': sum(1 for t in self.shared_metadata.get('tags', {}).values() if t.get('is_manifesto')),
            'portrait_count': sum(1 for t in self.shared_metadata.get('tags', {}).values() if t.get('is_portrait')),
            'contributors': self.shared_metadata.get('contributors', {}),
            'last_sync': self.shared_metadata.get('last_sync')
        }
        return stats

def create_browser_sync_script():
    """Create a JavaScript snippet for browser console to export/import tags"""
    
    js_script = """
// SOLIENNE Tag Export/Import Script
// Run this in browser console to sync tags

// Export tags from browser
function exportTags() {
    const tags = localStorage.getItem('solienne-manual-tags');
    if (tags) {
        console.log('📤 Exporting tags...');
        const blob = new Blob([tags], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `solienne_tags_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        console.log('✅ Tags exported');
    } else {
        console.log('❌ No tags found');
    }
}

// Import tags to browser
function importTags(jsonString) {
    try {
        const tags = typeof jsonString === 'string' ? JSON.parse(jsonString) : jsonString;
        localStorage.setItem('solienne-manual-tags', JSON.stringify(tags));
        console.log('✅ Tags imported. Refresh page to see changes.');
        location.reload();
    } catch (e) {
        console.error('❌ Import failed:', e);
    }
}

// Get current tag stats
function getTagStats() {
    const tags = JSON.parse(localStorage.getItem('solienne-manual-tags') || '{}');
    const manifestos = Object.values(tags).filter(t => t.is_manifesto).length;
    const portraits = Object.values(tags).filter(t => t.is_portrait).length;
    console.log(`📊 Tag Stats:
    Total tagged: ${Object.keys(tags).length}
    Manifestos: ${manifestos}
    Portraits: ${portraits}`);
}

console.log('🎨 SOLIENNE Tag Sync Tools Loaded');
console.log('Commands: exportTags(), importTags(json), getTagStats()');
"""
    
    return js_script

if __name__ == "__main__":
    import sys
    
    # Command line interface
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        sync = MetadataSync(user_id=os.getenv('USER', 'unknown'))
        
        if command == "export":
            # Export for browser
            tags = sync.export_for_browser()
            output_file = Path("browser_tags_export.json")
            with open(output_file, 'w') as f:
                json.dump(tags, f, indent=2)
            print(f"✅ Exported {len(tags)} tags to {output_file}")
            
        elif command == "import":
            # Import from browser
            if len(sys.argv) > 2:
                import_file = Path(sys.argv[2])
                if import_file.exists():
                    with open(import_file) as f:
                        browser_tags = json.load(f)
                    sync.import_from_browser(browser_tags)
                    print(f"✅ Imported {len(browser_tags)} tags")
                else:
                    print(f"❌ File not found: {import_file}")
            else:
                print("Usage: python metadata_sync_service.py import <file.json>")
                
        elif command == "stats":
            # Show statistics
            stats = sync.get_sync_stats()
            print("📊 SOLIENNE Metadata Statistics:")
            print(f"  Total tags: {stats['total_tags']}")
            print(f"  Manifestos: {stats['manifesto_count']}")
            print(f"  Portraits: {stats['portrait_count']}")
            print(f"  Last sync: {stats['last_sync']}")
            print("\nContributors:")
            for user, info in stats['contributors'].items():
                print(f"  {user}: {info['tag_count']} tags")
                
        elif command == "js":
            # Output JavaScript sync script
            print(create_browser_sync_script())
            
        else:
            print("Commands: export, import <file>, stats, js")
    else:
        print("SOLIENNE Metadata Sync Service")
        print("Usage: python metadata_sync_service.py [export|import|stats|js]")