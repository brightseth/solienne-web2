#!/usr/bin/env python3
"""
SOLIENNE Browser Setup for Kristi
Complete deployment and sync system
"""

import os
import sys
import json
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

class SolienneSetup:
    def __init__(self):
        self.setup_dir = Path.home() / "SOLIENNE_BROWSER"
        self.images_dir = self.setup_dir / "images"
        self.eden_dir = self.setup_dir / "eden_downloads"
        self.metadata_dir = self.setup_dir / "metadata"
        
    def create_directories(self):
        """Create necessary directories"""
        print("📁 Creating directory structure...")
        self.setup_dir.mkdir(exist_ok=True)
        self.images_dir.mkdir(exist_ok=True)
        self.eden_dir.mkdir(exist_ok=True)
        self.metadata_dir.mkdir(exist_ok=True)
        
        # Create subdirectories for organization
        (self.metadata_dir / "manual_tags").mkdir(exist_ok=True)
        (self.metadata_dir / "sync_logs").mkdir(exist_ok=True)
        print("✅ Directories created")
        
    def install_python_packages(self):
        """Install required Python packages"""
        print("\n📦 Installing Python packages...")
        packages = ["requests", "Pillow", "aiohttp", "python-dateutil"]
        
        for package in packages:
            print(f"  Installing {package}...")
            subprocess.run([sys.executable, "-m", "pip", "install", package], 
                         capture_output=True)
        print("✅ Python packages installed")
        
    def copy_browser_files(self):
        """Copy browser and server files"""
        print("\n📋 Copying browser files...")
        
        # Copy main browser file
        browser_src = Path(__file__).parent / "solienne_browser_final.html"
        if browser_src.exists():
            shutil.copy2(browser_src, self.setup_dir / "solienne_browser.html")
            print("  ✅ Browser interface copied")
        
        # Copy server file
        server_src = Path(__file__).parent / "local_solienne_server.py"
        if server_src.exists():
            shutil.copy2(server_src, self.setup_dir / "server.py")
            print("  ✅ Server copied")
            
        # Copy Eden sync script
        sync_src = Path(__file__).parent / "eden_sync.py"
        if sync_src.exists():
            shutil.copy2(sync_src, self.setup_dir / "eden_sync.py")
            print("  ✅ Eden sync script copied")
            
        # Copy manifesto whitelist
        whitelist_src = Path(__file__).parent / "manifesto_whitelist.json"
        if whitelist_src.exists():
            shutil.copy2(whitelist_src, self.metadata_dir / "manifesto_whitelist.json")
            print("  ✅ Manifesto whitelist copied")
            
    def create_config(self):
        """Create configuration file"""
        print("\n⚙️  Creating configuration...")
        
        config = {
            "version": "1.0.0",
            "setup_date": datetime.now().isoformat(),
            "paths": {
                "browser": str(self.setup_dir / "solienne_browser.html"),
                "server": str(self.setup_dir / "server.py"),
                "images": str(self.images_dir),
                "eden_downloads": str(self.eden_dir),
                "metadata": str(self.metadata_dir)
            },
            "server": {
                "host": "localhost",
                "port": 5002
            },
            "eden_api": {
                "base_url": "https://api.eden.art",
                "check_interval_hours": 24,
                "auto_sync": True,
                "max_works": 100
            },
            "metadata_sync": {
                "enabled": True,
                "sync_url": "https://solienne-sync.vercel.app/api/metadata",
                "sync_interval_hours": 6,
                "share_tags": True,
                "share_favorites": False
            }
        }
        
        with open(self.setup_dir / "config.json", 'w') as f:
            json.dump(config, f, indent=2)
        print("✅ Configuration created")
        
    def create_launcher(self):
        """Create launcher scripts"""
        print("\n🚀 Creating launcher scripts...")
        
        # Mac/Linux launcher
        bash_launcher = """#!/bin/bash
# SOLIENNE Browser Launcher

echo "🎨 Starting SOLIENNE Browser..."
cd "$(dirname "$0")"

# Start the server
echo "Starting local server..."
python3 server.py &
SERVER_PID=$!

# Wait for server to start
sleep 2

# Open browser
echo "Opening browser..."
open "http://localhost:5002" || xdg-open "http://localhost:5002" || open solienne_browser.html

echo "✅ SOLIENNE Browser is running"
echo "Press Ctrl+C to stop"

# Wait for user to stop
trap "kill $SERVER_PID 2>/dev/null; echo 'Server stopped'" EXIT
wait $SERVER_PID
"""
        
        launcher_path = self.setup_dir / "start_browser.sh"
        with open(launcher_path, 'w') as f:
            f.write(bash_launcher)
        os.chmod(launcher_path, 0o755)
        print("  ✅ Mac/Linux launcher created")
        
        # Windows launcher
        bat_launcher = """@echo off
echo Starting SOLIENNE Browser...
cd /d "%~dp0"

echo Starting local server...
start /b python server.py

timeout /t 2 /nobreak > nul

echo Opening browser...
start http://localhost:5002

echo.
echo SOLIENNE Browser is running
echo Press Ctrl+C in this window to stop the server
pause
"""
        
        with open(self.setup_dir / "start_browser.bat", 'w') as f:
            f.write(bat_launcher)
        print("  ✅ Windows launcher created")
        
    def create_sync_script(self):
        """Create daily sync script"""
        print("\n🔄 Creating sync scripts...")
        
        sync_script = """#!/usr/bin/env python3
'''
SOLIENNE Daily Sync
Syncs latest works from Eden and updates shared metadata
'''

import json
import requests
import subprocess
from pathlib import Path
from datetime import datetime

def sync_eden():
    '''Sync latest works from Eden'''
    print(f"🔄 Syncing Eden works at {datetime.now()}")
    
    # Run Eden sync
    subprocess.run([sys.executable, "eden_sync.py", "--limit", "50"])
    
def sync_metadata():
    '''Sync manual tags with cloud'''
    config_path = Path(__file__).parent / "config.json"
    
    with open(config_path) as f:
        config = json.load(f)
    
    if not config["metadata_sync"]["enabled"]:
        return
        
    print("☁️  Syncing metadata with cloud...")
    
    # Load local manual tags
    local_tags_path = Path(__file__).parent / "metadata" / "manual_tags" / "tags.json"
    if local_tags_path.exists():
        with open(local_tags_path) as f:
            local_tags = json.load(f)
        
        # Send to sync server
        try:
            response = requests.post(
                config["metadata_sync"]["sync_url"],
                json={"tags": local_tags, "user": "kristi"},
                timeout=30
            )
            
            if response.status_code == 200:
                # Merge with cloud tags
                cloud_tags = response.json().get("tags", {})
                
                # Merge tags (cloud wins on conflicts)
                for work_id, tags in cloud_tags.items():
                    if work_id not in local_tags:
                        local_tags[work_id] = tags
                
                # Save merged tags
                with open(local_tags_path, 'w') as f:
                    json.dump(local_tags, f, indent=2)
                    
                print("✅ Metadata synced successfully")
        except Exception as e:
            print(f"⚠️ Metadata sync failed: {e}")

if __name__ == "__main__":
    sync_eden()
    sync_metadata()
    print("✅ Daily sync complete")
"""
        
        with open(self.setup_dir / "daily_sync.py", 'w') as f:
            f.write(sync_script)
        print("✅ Sync script created")
        
    def create_readme(self):
        """Create README for Kristi"""
        print("\n📝 Creating README...")
        
        readme = """# SOLIENNE Browser - Kristi's Installation

## 🎨 Welcome!
This is your local SOLIENNE browser for managing and curating SOLIENNE's digital consciousness artworks.

## 🚀 Quick Start

### To Start the Browser:
**On Mac:**
1. Double-click `start_browser.sh` 
   OR
2. Open Terminal and run: `./start_browser.sh`

**On Windows:**
1. Double-click `start_browser.bat`

The browser will open automatically at http://localhost:5002

## 📅 Daily Updates

### Automatic Daily Sync:
The system automatically syncs new SOLIENNE works from Eden every day.

### Manual Sync:
To manually sync latest works:
1. Open Terminal/Command Prompt
2. Navigate to this folder
3. Run: `python3 daily_sync.py`

## 🏷️ Tagging & Metadata

### Quick Tagging in Browser:
When viewing a work in the lightbox:
- Click **Manifesto** to tag as manifesto
- Click **Portrait** to tag as portrait  
- Click **Neither** to clear tags

Your tags are automatically saved and will persist across sessions.

### Metadata Syncing:
- Your manual tags sync with the cloud every 6 hours
- Tags are shared between your laptop and Seth's system
- Favorites remain local to your device

## 📁 Folder Structure

```
SOLIENNE_BROWSER/
├── images/                 # Local SOLIENNE images
├── eden_downloads/         # Works downloaded from Eden
├── metadata/              
│   ├── manual_tags/       # Your tag corrections
│   └── sync_logs/         # Sync history
├── solienne_browser.html  # Browser interface
├── server.py              # Local server
├── eden_sync.py           # Eden sync script
├── daily_sync.py          # Daily update script
├── config.json            # Configuration
└── start_browser.sh/.bat  # Launcher scripts
```

## 🔍 Browser Features

### Filters:
- **All Consciousness** - View all works
- **Digital Manifestos** - Text-based works only
- **Neural Portraits** - Portrait works only
- **This Week** - Recent works from last 7 days
- **Today** - Today's works only

### Key Actions:
- **Find Similar** - Find visually similar works
- **Download** - Save work to your computer
- **Share** - Share work link
- **Add to Vote** - Add to voting campaign
- **Favorite** - Save to favorites (⭐)

### Search:
Use the search bar to find works by:
- Title
- Prompt text
- Creation date
- Any metadata

## 🆘 Troubleshooting

### Browser won't open:
1. Make sure Python 3 is installed
2. Check if port 5002 is available
3. Try opening http://localhost:5002 manually

### Images not loading:
1. Run the sync script: `python3 daily_sync.py`
2. Check your internet connection
3. Verify the server is running

### Server crashes:
1. Close all browser tabs
2. Stop the server (Ctrl+C)
3. Restart using the launcher script

## 📞 Support

If you need help:
1. Check the sync logs in `metadata/sync_logs/`
2. Contact Seth with any error messages
3. Your data is automatically backed up to the cloud

## 🎯 Daily Workflow

1. **Start Browser**: Double-click launcher script
2. **Review New Works**: Check "This Week" filter for latest
3. **Tag Corrections**: Fix any misclassified manifestos/portraits
4. **Curate**: Add best works to favorites
5. **Close**: Press Ctrl+C in terminal when done

---

Last Updated: {date}
Version: 1.0.0
"""
        
        with open(self.setup_dir / "README.md", 'w') as f:
            f.write(readme.format(date=datetime.now().strftime("%B %d, %Y")))
        print("✅ README created")
        
    def copy_existing_images(self):
        """Copy existing images if available"""
        print("\n🖼️  Copying existing images...")
        
        source_images = Path(__file__).parent / "images"
        if source_images.exists():
            image_count = 0
            for img in source_images.glob("*"):
                if img.suffix.lower() in ['.jpg', '.jpeg', '.png', '.webp']:
                    shutil.copy2(img, self.images_dir)
                    image_count += 1
                    if image_count % 100 == 0:
                        print(f"  Copied {image_count} images...")
            print(f"✅ Copied {image_count} images")
        else:
            print("⚠️  No existing images found")
            
    def run_initial_sync(self):
        """Run initial Eden sync"""
        print("\n🔄 Running initial Eden sync...")
        
        os.chdir(self.setup_dir)
        result = subprocess.run([sys.executable, "eden_sync.py", "--limit", "50"], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Initial sync complete")
        else:
            print(f"⚠️  Sync had issues: {result.stderr}")
            
    def setup_all(self):
        """Run complete setup"""
        print("=" * 60)
        print("🎨 SOLIENNE BROWSER SETUP FOR KRISTI")
        print("=" * 60)
        
        self.create_directories()
        self.install_python_packages()
        self.copy_browser_files()
        self.create_config()
        self.create_launcher()
        self.create_sync_script()
        self.create_readme()
        self.copy_existing_images()
        
        print("\n" + "=" * 60)
        print("✅ SETUP COMPLETE!")
        print("=" * 60)
        print(f"\n📁 Installation location: {self.setup_dir}")
        print("\n🚀 To start the browser:")
        print(f"   Mac/Linux: {self.setup_dir}/start_browser.sh")
        print(f"   Windows: {self.setup_dir}/start_browser.bat")
        print("\n📖 See README.md for full instructions")

if __name__ == "__main__":
    setup = SolienneSetup()
    setup.setup_all()