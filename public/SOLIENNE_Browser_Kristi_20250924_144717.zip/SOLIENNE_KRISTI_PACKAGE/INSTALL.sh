#!/bin/bash
echo "🎨 SOLIENNE Browser Installer"
echo "=============================="
echo ""
echo "This will install SOLIENNE Browser on your computer."
echo "Installation location: ~/SOLIENNE_BROWSER"
echo ""
read -p "Continue? (y/n) " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Installing..."
    python3 setup.py
    echo ""
    echo "✅ Installation complete!"
    echo ""
    echo "To start the browser:"
    echo "  cd ~/SOLIENNE_BROWSER"
    echo "  ./start_browser.sh"
else
    echo "Installation cancelled."
fi
