#!/usr/bin/env python3
"""
Local SOLIENNE Image Server
Serves images and metadata from local SOLIENNE KRISTI OUTPUTS folder
"""

import os
import json
import glob
from flask import Flask, jsonify, send_file, request
from flask_cors import CORS
from datetime import datetime
import hashlib
from PIL import Image
import numpy as np

app = Flask(__name__)
CORS(app)

# Configuration
BASE_PATH = "/Users/seth/Desktop/SOLIENNE KRISTI OUTPUTS"
CREATIONS_PATH = os.path.join(BASE_PATH, "solienne_creations")
USER_DATA_PATH = os.path.join(BASE_PATH, "user_data_export.json")
ANALYSIS_PATH = "/Users/seth/Downloads/solienne_analysis_results.json"

# Cache for processed data
works_cache = None
metadata_cache = None
analysis_cache = None

def load_analysis():
    """Load image analysis data if available"""
    global analysis_cache
    if analysis_cache is None and os.path.exists(ANALYSIS_PATH):
        try:
            with open(ANALYSIS_PATH, 'r') as f:
                analysis_cache = json.load(f)
        except:
            analysis_cache = {}
    return analysis_cache or {}

def load_metadata():
    """Load and process user data export"""
    global metadata_cache
    if metadata_cache is None:
        metadata_cache = {}
        try:
            with open(USER_DATA_PATH, 'r') as f:
                user_data = json.load(f)
                
            # Extract creations from sessions
            creations = {}
            for session in user_data.get('sessions', []):
                for message in session.get('messages', []):
                    if message.get('role') == 'assistant':
                        for tool_call in message.get('tool_calls', []):
                            if tool_call.get('status') == 'completed' and tool_call.get('result'):
                                for result in tool_call['result']:
                                    if isinstance(result, dict):
                                        for output in result.get('output', []):
                                            if isinstance(output, dict):
                                                creation_id = output.get('creation')
                                                if creation_id:
                                                    creations[creation_id] = {
                                                        'id': creation_id,
                                                        'url': output.get('url'),
                                                        'prompt': tool_call.get('args', {}).get('prompt', ''),
                                                        'timestamp': message.get('created_at', ''),
                                                        'session_title': session.get('title', ''),
                                                        'width': output.get('mediaAttributes', {}).get('width'),
                                                        'height': output.get('mediaAttributes', {}).get('height')
                                                    }
            
            metadata_cache = creations
            print(f"Loaded {len(creations)} creations from metadata")
        except Exception as e:
            print(f"Error loading metadata: {e}")
            import traceback
            traceback.print_exc()
    
    return metadata_cache

def get_local_images():
    """Get all local image files"""
    png_files = glob.glob(os.path.join(CREATIONS_PATH, "*.png"))
    jpg_files = glob.glob(os.path.join(CREATIONS_PATH, "*.jpg"))
    jpeg_files = glob.glob(os.path.join(CREATIONS_PATH, "*.jpeg"))
    
    all_files = png_files + jpg_files + jpeg_files
    return sorted(all_files, key=lambda x: os.path.getmtime(x), reverse=True)

def process_works():
    """Process all works combining local files and metadata"""
    global works_cache
    
    if works_cache is None:
        works = []
        metadata = load_metadata()
        analysis = load_analysis()
        local_files = get_local_images()
        seen_ids = set()  # For deduplication
        
        # Create a map of filenames to local paths
        file_map = {}
        for filepath in local_files:
            filename = os.path.basename(filepath)
            # Try to extract creation ID from filename
            # Format: YYYY-MM-DD_HHMM_creationId.ext
            parts = filename.split('_')
            if len(parts) >= 3:
                creation_id = parts[2].split('.')[0]
                file_map[creation_id] = filepath
            # Also map by full filename
            file_map[filename] = filepath
        
        # Process metadata entries
        for creation_id, meta in metadata.items():
            # Skip duplicates
            if creation_id in seen_ids:
                continue
            seen_ids.add(creation_id)
            
            # Only include if we have a local file
            local_path = file_map.get(creation_id)
            if not local_path:
                continue
                
            work = {
                'id': creation_id,
                'title': meta.get('session_title', ''),
                'prompt': meta.get('prompt', ''),
                'timestamp': meta.get('timestamp', ''),
                'url': f'/image/{creation_id}',
                'thumbnail': f'/image/{creation_id}?thumb=true',
                'width': meta.get('width', 1024),
                'height': meta.get('height', 1024),
                'local_path': local_path,
                'has_local': True,
                'user': detect_user(meta.get('prompt', ''))  # Detect user from prompt
            }
            
            # Add analysis data if available
            for analysis_file, analysis_data in analysis.items():
                if creation_id in analysis_file:
                    work['labels'] = analysis_data.get('labels', [])
                    work['hasFace'] = analysis_data.get('hasFace', False)
                    work['confidence'] = analysis_data.get('confidence', 0)
                    break
            
            # Detect manifestos, portraits, and B&W
            work['is_manifesto'] = detect_manifesto(work)
            work['is_portrait'] = detect_portrait(work)
            work['is_bw'] = detect_bw(work)
            
            works.append(work)
        
        # Add orphan local files (not in metadata)
        for filepath in local_files:
            filename = os.path.basename(filepath)
            
            # Skip if already processed
            parts = filename.split('_')
            if len(parts) >= 3:
                creation_id = parts[2].split('.')[0]
                if creation_id in seen_ids:
                    continue
            
            # Create unique ID for orphan file
            file_id = hashlib.md5(filename.encode()).hexdigest()[:24]
            if file_id in seen_ids:
                continue
            seen_ids.add(file_id)
            
            # Extract date from filename if possible
            timestamp = datetime.fromtimestamp(os.path.getmtime(filepath)).isoformat()
            if len(parts) >= 2:
                try:
                    date_str = parts[0]
                    time_str = parts[1]
                    timestamp = f"{date_str}T{time_str[:2]}:{time_str[2:]}:00"
                except:
                    pass
            
            # Verify file exists
            if not os.path.exists(filepath):
                continue
                
            work = {
                'id': file_id,
                'title': 'CONSCIOUSNESS STREAM',
                'prompt': 'Local consciousness exploration',
                'timestamp': timestamp,
                'url': f'/local/{filename}',
                'thumbnail': f'/local/{filename}?thumb=true',
                'local_path': filepath,
                'has_local': True,
                'is_orphan': True,
                'user': 'kristi'  # Default orphan files to kristi
            }
            
            # Check analysis data
            for analysis_file, analysis_data in analysis.items():
                if filename in analysis_file or file_id in analysis_file:
                    work['labels'] = analysis_data.get('labels', [])
                    work['hasFace'] = analysis_data.get('hasFace', False)
                    work['confidence'] = analysis_data.get('confidence', 0)
                    break
            
            # Detect manifestos, portraits, and B&W
            work['is_manifesto'] = detect_manifesto(work)
            work['is_portrait'] = detect_portrait(work)
            work['is_bw'] = detect_bw(work)
            
            works.append(work)
        
        # Sort by timestamp
        works.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        works_cache = works
        
        print(f"Total works with valid local files: {len(works)}")
        print(f"- From metadata with files: {len([w for w in works if not w.get('is_orphan')])}")
        print(f"- Orphan files: {len([w for w in works if w.get('is_orphan')])}")
    
    return works_cache

def detect_bw(work):
    """Detect if an image is black and white"""
    local_path = work.get('local_path')
    if not local_path or not os.path.exists(local_path):
        # Default to False if we can't check
        return False
    
    try:
        # Open image and convert to RGB
        img = Image.open(local_path).convert('RGB')
        
        # Sample the image (resize for faster processing)
        sample_size = 100
        img_sample = img.resize((sample_size, sample_size), Image.Resampling.LANCZOS)
        
        # Convert to numpy array
        pixels = np.array(img_sample)
        
        # Calculate color variance
        # For B&W images, R, G, B values should be similar
        r, g, b = pixels[:,:,0], pixels[:,:,1], pixels[:,:,2]
        
        # Calculate standard deviation between channels
        diff_rg = np.abs(r - g).mean()
        diff_rb = np.abs(r - b).mean()
        diff_gb = np.abs(g - b).mean()
        
        # If average difference between channels is low, it's likely B&W
        avg_diff = (diff_rg + diff_rb + diff_gb) / 3
        
        # Threshold for B&W detection (adjust as needed)
        return bool(avg_diff < 10)
        
    except Exception as e:
        # If we can't analyze the image, default to False
        return False

def detect_manifesto(work):
    """Detect if a work is a manifesto - text-based images with statements"""
    text = (work.get('prompt', '') + ' ' + work.get('title', '')).lower()
    
    # Very strong indicators - almost always manifestos
    if 'manifesto' in text or 'openai' in text or 'dall-e' in text:
        return True
    
    # Text-heavy indicators
    manifesto_keywords = [
        'statement', 'declaration', 'text', 'words', 'typography',
        'message', 'proclamation', 'thesis', 'doctrine', 'written',
        'quote', 'zine', 'poster', 'pamphlet', 'announcement',
        'radical', 'revolution', 'typeface', 'font', 'letters'
    ]
    
    # Count matches
    matches = sum(1 for keyword in manifesto_keywords if keyword in text)
    
    # If it has portrait keywords, it's likely NOT a manifesto
    portrait_keywords = ['portrait', 'face', 'eyes', 'smile', 'person', 'human', 'selfie']
    has_portrait_words = any(keyword in text for keyword in portrait_keywords)
    
    # Manifestos need strong text indicators and no portrait indicators
    if has_portrait_words:
        return False
    
    return matches >= 2

def detect_portrait(work):
    """Detect if a work is a portrait"""
    # Check labels for portrait indicators
    labels = work.get('labels', [])
    portrait_indicators = ['portrait', 'face', 'facial expression', 'eyebrow', 'lips', 'jaw', 'close-up']
    has_portrait_label = any(label in labels for label in portrait_indicators)
    
    # Check hasFace flag (strong indicator)
    has_face = work.get('hasFace', False)
    
    # Enhanced prompt text analysis
    text = (work.get('prompt', '') + ' ' + work.get('title', '')).lower()
    portrait_keywords = [
        'portrait', 'face', 'facial', 'profile', 'expression', 'gaze',
        'eyes', 'smile', 'lips', 'eyebrow', 'jaw', 'cheek', 'forehead',
        'nose', 'mouth', 'chin', 'selfie', 'headshot', 'close-up',
        'person', 'human', 'figure', 'character', 'individual',
        'looking', 'staring', 'glancing', 'emotion', 'mood'
    ]
    
    # Strong indicators (definitive portrait keywords)
    strong_indicators = ['portrait', 'face', 'facial', 'headshot', 'selfie']
    has_strong_text = any(keyword in text for keyword in strong_indicators)
    
    # Multiple weak indicators suggest portrait
    weak_matches = sum(1 for keyword in portrait_keywords if keyword in text)
    has_multiple_indicators = weak_matches >= 2
    
    return has_face or has_portrait_label or has_strong_text or has_multiple_indicators

def detect_user(prompt):
    """Detect user from prompt content
    
    Note: This is a best-guess heuristic. SOLIENNE is Kristi's AI agent,
    so most works are likely hers unless clearly indicated otherwise.
    """
    prompt_lower = prompt.lower() if prompt else ""
    
    # Very specific Seth/Abraham project keywords
    seth_specific = [
        'abraham', 'gene kogan', 'autonomous artist', 'truth terminal',
        'post-democratic', 'covenant', 'radical self-reliance'
    ]
    
    # If it has very specific Seth/Abraham content
    if any(keyword in prompt_lower for keyword in seth_specific):
        return 'seth'
    
    # Default to Kristi (SOLIENNE's creator) - most works are hers
    return 'kristi'

@app.route('/')
def index():
    """Basic server info page"""
    return """
    <h1>SOLIENNE Local Server</h1>
    
    <h2>🎨 Quick Access</h2>
    <p><strong>Browser Interface:</strong> <a href="file:///Users/seth/SOLIENNE_V2/solienne_local_browser.html" target="_blank">Open Gallery</a></p>
    
    <h2>🔄 Sorting Options</h2>
    <ul>
        <li><a href="/api/works?sort=newest">Newest First</a> (default)</li>
        <li><a href="/api/works?sort=oldest">Oldest First</a></li>
        <li><a href="/api/works?sort=random">Random Order</a></li>
    </ul>
    
    <h2>📅 Browse by Month</h2>
    <ul>
        <li><a href="/api/works?month=2025-09">September 2025</a></li>
        <li><a href="/api/works?month=2025-08">August 2025</a></li>
        <li><a href="/api/works?month=2025-07">July 2025</a></li>
    </ul>
    
    <h2>🎯 Filters</h2>
    <ul>
        <li><a href="/api/works?filter=portraits">Portraits (2,497)</a></li>
        <li><a href="/api/works?filter=manifestos">Manifestos (464)</a></li>
        <li><a href="/api/works?filter=highres">High-res (1,569)</a></li>
    </ul>
    
    <h2>📊 Stats</h2>
    <p><a href="/stats">Collection Statistics</a></p>
    """

@app.route('/api/works')
def get_works():
    """Get all SOLIENNE works"""
    works = process_works()
    
    # Apply user filter
    user_filter = request.args.get('user', '').lower()
    if user_filter in ['kristi', 'seth']:
        works = [w for w in works if w.get('user', '').lower() == user_filter]
    
    # Apply sorting
    sort_by = request.args.get('sort', '').lower()
    if sort_by == 'oldest':
        works = sorted(works, key=lambda x: x.get('timestamp', ''))
    elif sort_by == 'newest':
        works = sorted(works, key=lambda x: x.get('timestamp', ''), reverse=True)
    elif sort_by == 'random':
        import random
        works = works.copy()
        random.shuffle(works)
    elif sort_by == 'confidence':
        works = sorted(works, key=lambda x: x.get('confidence', 0), reverse=True)
    # Default is already newest first from process_works()
    
    # Apply filters
    filter_type = request.args.get('filter', '').lower()
    if filter_type == 'portraits':
        works = [w for w in works if w.get('is_portrait', False)]
    elif filter_type == 'manifestos':
        works = [w for w in works if w.get('is_manifesto', False)]
    elif filter_type == 'faces':
        works = [w for w in works if w.get('hasFace', False)]
    elif filter_type == 'orphans':
        works = [w for w in works if w.get('is_orphan', False)]
    elif filter_type == 'analyzed':
        works = [w for w in works if w.get('labels', [])]
    elif filter_type == 'recent':
        # Last 30 days worth based on most recent timestamps
        works = works[:min(len(works), 300)]  # Approximate recent works
    elif filter_type == 'highres':
        works = [w for w in works if (w.get('width') or 0) >= 1024 and (w.get('height') or 0) >= 1024]
    elif filter_type == 'bw':
        works = [w for w in works if w.get('is_bw', False)]
    elif filter_type == 'color':
        works = [w for w in works if not w.get('is_bw', False)]
    
    # Apply month filter
    month_filter = request.args.get('month', '')
    if month_filter:  # Format: YYYY-MM
        works = [w for w in works if w.get('timestamp', '').startswith(month_filter)]
    
    # Apply search filter if provided
    search = request.args.get('search', '').lower()
    if search:
        filtered = []
        for work in works:
            # Check for special filters
            if search == 'portrait' or search == 'portraits':
                if work.get('is_portrait', False):
                    filtered.append(work)
            elif search == 'manifesto' or search == 'manifestos':
                if work.get('is_manifesto', False):
                    filtered.append(work)
            else:
                # Regular text search
                if (search in work.get('title', '').lower() or
                    search in work.get('prompt', '').lower() or
                    any(search in label.lower() for label in work.get('labels', []))):
                    filtered.append(work)
        works = filtered
    
    # Apply pagination
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 100))
    start = (page - 1) * per_page
    end = start + per_page
    
    all_works = process_works()
    return jsonify({
        'works': works[start:end],
        'total': len(works),
        'page': page,
        'per_page': per_page,
        'total_pages': (len(works) + per_page - 1) // per_page,
        'filters': {
            'portraits': len([w for w in all_works if w.get('is_portrait', False)]),
            'manifestos': len([w for w in all_works if w.get('is_manifesto', False)]),
            'faces': len([w for w in all_works if w.get('hasFace', False)]),
            'orphans': len([w for w in all_works if w.get('is_orphan', False)]),
            'analyzed': len([w for w in all_works if w.get('labels', [])]),
            'highres': len([w for w in all_works if (w.get('width') or 0) >= 1024 and (w.get('height') or 0) >= 1024]),
            'bw': len([w for w in all_works if w.get('is_bw', False)]),
            'color': len([w for w in all_works if not w.get('is_bw', False)]),
            'kristi': len([w for w in all_works if w.get('user', '') == 'kristi']),
            'seth': len([w for w in all_works if w.get('user', '') == 'seth'])
        }
    })

@app.route('/image/<creation_id>')
def serve_image_by_id(creation_id):
    """Serve image by creation ID"""
    works = process_works()
    for work in works:
        if work['id'] == creation_id and work.get('local_path'):
            if os.path.exists(work['local_path']):
                return send_file(work['local_path'], mimetype='image/png')
    return "Image not found", 404

@app.route('/local/<filename>')
def serve_local_file(filename):
    """Serve local file directly"""
    filepath = os.path.join(CREATIONS_PATH, filename)
    if os.path.exists(filepath):
        # Determine mimetype
        ext = filename.lower().split('.')[-1]
        mimetype = 'image/jpeg' if ext in ['jpg', 'jpeg'] else 'image/png'
        return send_file(filepath, mimetype=mimetype)
    return "File not found", 404

@app.route('/api/embeddings')
def get_embeddings():
    """Serve semantic embeddings for similarity search"""
    embeddings_path = '/Users/seth/SOLIENNE_V2/browser_semantic.json'
    if os.path.exists(embeddings_path):
        return send_file(embeddings_path, mimetype='application/json')
    else:
        return jsonify({'error': 'Embeddings not found'}), 404

@app.route('/stats')
def get_stats():
    """Get statistics about the collection"""
    works = process_works()
    analysis = load_analysis()
    
    return jsonify({
        'total_works': len(works),
        'with_local_files': len([w for w in works if w.get('has_local')]),
        'orphan_files': len([w for w in works if w.get('is_orphan')]),
        'with_analysis': len([w for w in works if w.get('labels')]),
        'with_faces': len([w for w in works if w.get('hasFace')]),
        'total_analysis_entries': len(analysis)
    })

if __name__ == '__main__':
    print(f"Starting SOLIENNE Local Server...")
    print(f"Base path: {BASE_PATH}")
    print(f"Loading data...")
    
    # Pre-load data
    works = process_works()
    print(f"Loaded {len(works)} works")
    
    print(f"Server running on http://localhost:5002")
    app.run(host='0.0.0.0', port=5002, debug=False)