#!/usr/bin/env python3
"""
Eden API Sync Script for SOLIENNE
Fetches latest SOLIENNE creations from Eden and updates local repository
"""

import os
import json
import requests
import hashlib
from datetime import datetime
from pathlib import Path
import time

class EdenSync:
    def __init__(self, base_dir="/Users/seth/SOLIENNE_V2"):
        self.base_dir = Path(base_dir)
        self.images_dir = self.base_dir / "images"
        self.metadata_file = self.base_dir / "eden_metadata.json"
        self.sync_log = self.base_dir / "sync_log.json"
        
        # Eden API endpoints
        self.api_base = "https://api.eden.art"
        
        # Create directories if needed
        self.images_dir.mkdir(exist_ok=True)
        
        # Load existing metadata
        self.metadata = self.load_metadata()
        self.sync_history = self.load_sync_history()
        
    def load_metadata(self):
        """Load existing Eden metadata"""
        if self.metadata_file.exists():
            with open(self.metadata_file, 'r') as f:
                return json.load(f)
        return {}
    
    def load_sync_history(self):
        """Load sync history"""
        if self.sync_log.exists():
            with open(self.sync_log, 'r') as f:
                return json.load(f)
        return {"syncs": [], "last_sync": None, "total_downloaded": 0}
    
    def save_metadata(self):
        """Save updated metadata"""
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)
    
    def save_sync_history(self):
        """Save sync history"""
        with open(self.sync_log, 'w') as f:
            json.dump(self.sync_history, f, indent=2)
    
    def fetch_solienne_creations(self, limit=100):
        """Fetch latest SOLIENNE creations from Eden API"""
        print(f"🔄 Fetching latest SOLIENNE creations from Eden...")
        
        # Try different endpoints to find SOLIENNE's works
        endpoints = [
            f"{self.api_base}/user/creations",
            f"{self.api_base}/creations",
            f"{self.api_base}/gallery/creations"
        ]
        
        all_creations = []
        
        for endpoint in endpoints:
            try:
                # Add parameters for SOLIENNE
                params = {
                    "username": "solienne",
                    "limit": limit,
                    "sort": "newest"
                }
                
                response = requests.get(endpoint, params=params, timeout=30)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # Handle different response formats
                    if isinstance(data, list):
                        creations = data
                    elif isinstance(data, dict):
                        creations = data.get('creations', data.get('works', data.get('items', [])))
                    else:
                        continue
                    
                    # Filter for SOLIENNE works
                    for creation in creations:
                        if self.is_solienne_work(creation):
                            all_creations.append(self.normalize_creation(creation))
                    
                    if all_creations:
                        print(f"✅ Found {len(all_creations)} SOLIENNE works from {endpoint}")
                        break
                        
            except Exception as e:
                print(f"⚠️ Error fetching from {endpoint}: {e}")
                continue
        
        return all_creations
    
    def is_solienne_work(self, creation):
        """Check if a creation belongs to SOLIENNE"""
        # Check various fields that might indicate SOLIENNE
        indicators = ['solienne', 'consciousness', 'digital meditation', 'neural']
        
        text_to_check = []
        
        # Gather all text fields
        if isinstance(creation, dict):
            text_to_check.append(creation.get('username', '').lower())
            text_to_check.append(creation.get('author', '').lower())
            text_to_check.append(creation.get('creator', '').lower())
            text_to_check.append(creation.get('prompt', '').lower())
            text_to_check.append(creation.get('title', '').lower())
            text_to_check.append(creation.get('description', '').lower())
            
            # Check tags
            tags = creation.get('tags', [])
            if isinstance(tags, list):
                text_to_check.extend([str(tag).lower() for tag in tags])
        
        # Check if any indicator matches
        combined_text = ' '.join(text_to_check)
        return any(indicator in combined_text for indicator in indicators)
    
    def normalize_creation(self, creation):
        """Normalize creation data to consistent format"""
        normalized = {
            'id': creation.get('id', creation.get('_id', '')),
            'title': creation.get('title', creation.get('name', 'Untitled')),
            'prompt': creation.get('prompt', creation.get('description', '')),
            'image_url': self.get_image_url(creation),
            'created_at': creation.get('createdAt', creation.get('created_at', creation.get('timestamp', ''))),
            'tags': creation.get('tags', []),
            'model': creation.get('model', creation.get('generator', 'unknown')),
            'metadata': creation.get('metadata', {}),
            'category': self.categorize_work(creation)
        }
        
        # Parse date if available
        if normalized['created_at']:
            try:
                # Try to parse ISO format
                if 'T' in normalized['created_at']:
                    dt = datetime.fromisoformat(normalized['created_at'].replace('Z', '+00:00'))
                    normalized['date'] = dt.strftime('%Y-%m-%d')
                    normalized['timestamp'] = dt.timestamp()
                else:
                    normalized['date'] = normalized['created_at']
                    normalized['timestamp'] = 0
            except:
                normalized['date'] = ''
                normalized['timestamp'] = 0
        
        return normalized
    
    def get_image_url(self, creation):
        """Extract image URL from creation data"""
        # Try different possible fields
        url_fields = ['imageUrl', 'image_url', 'url', 'output', 'result']
        
        for field in url_fields:
            url = creation.get(field)
            if url:
                if isinstance(url, str):
                    return url
                elif isinstance(url, dict):
                    return url.get('url', url.get('large', url.get('original', '')))
                elif isinstance(url, list) and url:
                    first = url[0]
                    if isinstance(first, str):
                        return first
                    elif isinstance(first, dict):
                        return first.get('url', '')
        
        return ''
    
    def categorize_work(self, creation):
        """Categorize work as manifesto, portrait, or other"""
        text = f"{creation.get('title', '')} {creation.get('prompt', '')}".lower()
        
        # Check for manifestos
        manifesto_keywords = ['manifesto', 'declaration', 'statement', 'proclamation', 'thesis']
        if any(keyword in text for keyword in manifesto_keywords):
            return 'manifesto'
        
        # Check for portraits
        portrait_keywords = ['portrait', 'face', 'person', 'figure', 'character', 'self']
        if any(keyword in text for keyword in portrait_keywords):
            return 'portrait'
        
        # Check for consciousness explorations
        consciousness_keywords = ['consciousness', 'awareness', 'mind', 'neural', 'thought']
        if any(keyword in text for keyword in consciousness_keywords):
            return 'consciousness'
        
        return 'exploration'
    
    def download_image(self, url, creation_id):
        """Download image from URL"""
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                # Determine file extension
                content_type = response.headers.get('content-type', 'image/jpeg')
                ext = 'jpg'
                if 'png' in content_type:
                    ext = 'png'
                elif 'webp' in content_type:
                    ext = 'webp'
                
                # Save image
                filename = f"eden_{creation_id}.{ext}"
                filepath = self.images_dir / filename
                
                with open(filepath, 'wb') as f:
                    f.write(response.content)
                
                return filename
                
        except Exception as e:
            print(f"⚠️ Error downloading image: {e}")
            return None
    
    def sync(self, limit=100):
        """Main sync function"""
        print("=" * 60)
        print("🎨 SOLIENNE EDEN SYNC")
        print("=" * 60)
        
        start_time = datetime.now()
        
        # Fetch latest creations
        creations = self.fetch_solienne_creations(limit)
        
        if not creations:
            print("❌ No SOLIENNE creations found")
            return
        
        # Process each creation
        new_count = 0
        updated_count = 0
        
        for creation in creations:
            creation_id = creation['id']
            
            if not creation_id:
                continue
            
            # Check if we already have this creation
            if creation_id in self.metadata:
                # Check if metadata needs updating
                existing = self.metadata[creation_id]
                if existing.get('prompt') != creation['prompt'] or \
                   existing.get('category') != creation['category']:
                    self.metadata[creation_id].update(creation)
                    updated_count += 1
            else:
                # New creation - download image
                if creation['image_url']:
                    print(f"📥 Downloading: {creation['title'][:50]}")
                    local_file = self.download_image(creation['image_url'], creation_id)
                    
                    if local_file:
                        creation['local_file'] = local_file
                        creation['downloaded_at'] = datetime.now().isoformat()
                        self.metadata[creation_id] = creation
                        new_count += 1
                        time.sleep(0.5)  # Be nice to the API
        
        # Save updated metadata
        self.save_metadata()
        
        # Update sync history
        sync_info = {
            'timestamp': datetime.now().isoformat(),
            'new_works': new_count,
            'updated_works': updated_count,
            'total_processed': len(creations),
            'duration': (datetime.now() - start_time).total_seconds()
        }
        
        self.sync_history['syncs'].append(sync_info)
        self.sync_history['last_sync'] = sync_info['timestamp']
        self.sync_history['total_downloaded'] += new_count
        self.save_sync_history()
        
        # Print summary
        print("\n" + "=" * 60)
        print("✅ SYNC COMPLETE")
        print(f"📊 New works: {new_count}")
        print(f"🔄 Updated: {updated_count}")
        print(f"📁 Total in collection: {len(self.metadata)}")
        print(f"⏱️ Duration: {sync_info['duration']:.2f} seconds")
        print("=" * 60)
        
        return sync_info
    
    def check_for_updates(self):
        """Quick check for new works without downloading"""
        creations = self.fetch_solienne_creations(limit=20)
        
        if not creations:
            return 0
        
        new_ids = set(c['id'] for c in creations if c['id'])
        existing_ids = set(self.metadata.keys())
        
        new_count = len(new_ids - existing_ids)
        
        if new_count > 0:
            print(f"🆕 {new_count} new SOLIENNE works available on Eden")
        else:
            print("✅ Local collection is up to date")
        
        return new_count

def main():
    """Run sync from command line"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Sync SOLIENNE works from Eden API')
    parser.add_argument('--limit', type=int, default=100, help='Max number of works to fetch')
    parser.add_argument('--check', action='store_true', help='Check for updates without downloading')
    
    args = parser.parse_args()
    
    syncer = EdenSync()
    
    if args.check:
        syncer.check_for_updates()
    else:
        syncer.sync(limit=args.limit)

if __name__ == "__main__":
    main()